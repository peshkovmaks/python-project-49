# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/peshkovmaks/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/peshkovmaks/python-project-49/actions)\n<a href="https://codeclimate.com/github/peshkovmaks/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b2364019d8f6c6065a65/maintainability" /></a>\n## These are 5 mathematical mini games for the terminal.\n### Game launch examples\nrun brain-even\n<a href="https://asciinema.org/a/5TS5PvrBJ37o29U2OR9oojlk2" target="_blank"><img src="https://asciinema.org/a/5TS5PvrBJ37o29U2OR9oojlk2.svg" /></a>\n\nrun brain-calc\n<a href="https://asciinema.org/a/cZ5sP3TgbWvAxvUY7SpkppqdX" target="_blank"><img src="https://asciinema.org/a/cZ5sP3TgbWvAxvUY7SpkppqdX.svg" /></a>\n\nrun brain-progression\n<a href="https://asciinema.org/a/iL0I4zlilPpv6BPZlHQfEkCEQ" target="_blank"><img src="https://asciinema.org/a/iL0I4zlilPpv6BPZlHQfEkCEQ.svg" /></a>\n\nrun brain-gcd\n<a href="https://asciinema.org/a/KEzNmamBpgzAYQSMle5Hp370W" target="_blank"><img src="https://asciinema.org/a/KEzNmamBpgzAYQSMle5Hp370W.svg" /></a>\n\nrun brain-prime\n<a href="https://asciinema.org/a/K4La1QPeMD7y0vo4M7rq6kl3D" target="_blank"><img src="https://asciinema.org/a/K4La1QPeMD7y0vo4M7rq6kl3D.svg" /></a>',
    'author': 'peshkovmaks',
    'author_email': 'peshkovmaks@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
