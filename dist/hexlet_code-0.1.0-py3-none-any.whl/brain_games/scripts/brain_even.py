#!/usr/bin/env python3
from brain_games.games import even


def main():
    even.start_game()


if __name__ == "__main__":
    main()
